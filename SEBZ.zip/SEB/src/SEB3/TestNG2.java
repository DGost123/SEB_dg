package SEB3;
//Lauko Purchase value validacijos testavimas
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class TestNG2 {
	WebDriver driver ;
	@Test
	public void f()  {
		String baseUrl = "https://www.seb.lt/skaiciuokles/lizingo-skaiciuokle";
        System.out.println("Launching Google Chrome browser"); 
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Daiva1\\Desktop\\configuration\\resources\\drivers\\chromedriver_win32\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get(baseUrl);
        driver.findElement(By.xpath("/html/body/div[4]/div/div[4]/ul/li[1]/a/span")).click();
        WebElement element6 = driver.findElement(By.xpath("//*[@id=\"menu01\"]/div[1]/div/div/ul/li/a/span")); 
        element6.click();
        System.out.println("paklikino English");
        driver.switchTo().frame("calculator-frame-06");
        //validuoja minimal� sumos dyd�
        WebElement element = driver.findElement(By.id("f-summa")); 
                System.out.println("paklikino");
        element.sendKeys("2");
        System.out.println("ivede");
        Actions action = new Actions(driver);
        action.sendKeys(Keys.ENTER).build().perform();
        String pran = "For amount up to 8 000 EUR we offer consumer loan";
        WebElement element15 = driver.findElement(By.id("f-summa-error")); 
        Assert.assertEquals(element15.getText(),pran, "N�ra prane�imo apie minimal� sumos dyd�");
        //validuoja �vest� duomen�  format�, kai laukas tu��ias
        element.clear();
        action.sendKeys(Keys.ENTER).build().perform();
        String formatas = "Wrong data format";
        WebElement element16 = driver.findElement(By.id("f-summa-error")); 
        Assert.assertEquals(element16.getText(),formatas, "Wrong data format prane�imo n�ra");
      //validuoja �vest� duomen�  format�, kai �vestas ne skai�ius 
        element.clear();
        element.sendKeys("2jjj9***");
        action.sendKeys(Keys.ENTER).build().perform();
        String formatas1 = "Wrong data format. The number must be greater than 0!";
        WebElement element17 = driver.findElement(By.id("f-summa-error")); 
        Assert.assertEquals(element17.getText(),formatas1, "N�ra prane�imo apie tai, kad �vestas ne skai�ius");
        //Kai �vedamas neigiamas skai�ius, turi rodyti prane�im�, kad suma turi b�ti teigiama
        element.clear();
        element.sendKeys("-70000");
        action.sendKeys(Keys.ENTER).build().perform();
        //patikrinti, ar klaidos atveju laukas nuspalvinamas raudonai
        String araudona= element.getCssValue("display");
        System.out.println("Color is : "+araudona);
        String spalva = "inline-block";
        Assert.assertEquals(araudona,spalva, "Nerodomas prane�imas apie tai, kad klaidos atveju laukas nnnnn�ra nuspalvinamas");
        //tikrinama, ar rodomas prane�imas apie tai, kad suma turi b�ti teigiama
        //testo rezultatas NOT PASSED, nes tokio prane�imo n�ra, bet tur�t� b�ti
        String formatas2 = "Wrong data format. The number must be greater than 0!";
        WebElement element18 = driver.findElement(By.id("f-summa-error")); 
        Assert.assertEquals(element18.getText(),formatas2, "N�ra prane�imo Wrong data format");
             
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Starting Test On Chrome Browser");
  }

  @AfterMethod
  public void afterMethod() {
	  driver.close();
	  System.out.println("Finished Test On Chrome Browser");
  }

}
