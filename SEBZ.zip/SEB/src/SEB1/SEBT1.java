package SEB1;
//Testas �veda korekti�kus duomenis lietuvi�koje Lizingo skai�iuokl�je ir palygina skai�iuokl�s suskai�iuotas
//lizingo �mokos, administravimo mokes�io ir pradin�s �mokos reik�mes su laukiamomis 
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.support.ui.Select;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.openqa.selenium.JavascriptExecutor;

public class SEBT1 {
	WebDriver driver ;
	@Test
	public void f()  {
		String baseUrl = "https://www.seb.lt/skaiciuokles/lizingo-skaiciuokle";
        System.out.println("Launching Google Chrome browser"); 
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Daiva1\\Desktop\\configuration\\resources\\drivers\\chromedriver_win32\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get(baseUrl);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.findElement(By.xpath("/html/body/div[4]/div/div[4]/ul/li[1]/a/span")).click();
        //capture the current started page heading and compare it with expected one
        String testTitle = "Autolizingo skai�iuokl� | SEB bankas";
        String originalTitle = driver.getTitle();
        Assert.assertEquals(originalTitle, testTitle);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.switchTo().frame("calculator-frame-06");
        //�vedami teisingi duomenys
        //�vedama lizingo suma
        WebElement element = driver.findElement(By.id("f-summa")); 
        element.click();
        System.out.println("paklikino");
        element.sendKeys("10000");
        System.out.println("ivede");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        //�vedamos pal�kanos
        WebElement element1 = driver.findElement(By.id("f-likme")); 
        element1.click();
        System.out.println("paklikino1");
        element1.clear();
        element1.sendKeys("4");
        System.out.println("ivede1");
        //pasirenkamas paskolos i�davimo terminas i� reik�mi� s�ra�o
        Select drptermins= new Select(driver.findElement(By.name("termins")));
        drptermins.selectByVisibleText("4 metai");
        //pasirenkamas pradin�s �mokos mato vienetas (Eur arba procentais)
        Select drpmaksa_type= new Select(driver.findElement(By.name("maksa_type")));
        drpmaksa_type.selectByVisibleText("Eur");
        //�vedama pradin�s �mokos reik�m�
        WebElement element2 = driver.findElement(By.id("f-maksa")); 
        element.click();
        System.out.println("paklikino2");
        element2.sendKeys("20");
        System.out.println("ivede2");
        //�vedamas likutis
        WebElement element3 = driver.findElement(By.id("f-rest")); 
        element3.click();
        System.out.println("paklikino3");
        element3.clear();
        element3.sendKeys("10");
        System.out.println("ivede3");
        //spaud�iamas mygtukas Skai�iuoti
        WebElement element4 = driver.findElement(By.xpath("/html/body/div/form/fieldset/div/div[1]/footer/div[2]/button")); 
        element4.click();
        System.out.println("paklikino4");
        //Lyginamos apskai�iuotos reik�m�s su laukiamomis
        String menimoka = "206.09";
        WebElement element5 = driver.findElement(By.xpath("/html/body/div/form/fieldset/div/div[2]/div[3]/div[2]/span[1]"));
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        String elementval = element5.getText();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Assert.assertEquals(elementval, menimoka);
         driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
         String comiss="200.00";
         WebElement element6 = driver.findElement(By.xpath("/html/body/div/form/fieldset/div/div[2]/div[4]/div[2]/span[1]"));
         String elementval1 = element6.getText();
         driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
         Assert.assertEquals(elementval1, comiss);
         driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
         String maksa="20.00";
         WebElement element7 = driver.findElement(By.xpath("/html/body/div/form/fieldset/div/div[2]/div[5]/div[2]/span[1]"));
         String elementval2 = element7.getText();
         driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
         Assert.assertEquals(elementval2, maksa);
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Starting Test On Chrome Browser");
	  	    }

  @AfterMethod
  public void afterMethod() {
	  driver.close();
	  System.out.println("Finished Test On Chrome Browser");
  }
}

