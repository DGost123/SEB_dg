package SEB2;
// SMOKE test for Payment shedule
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class TestNG1 {
	WebDriver driver ;
	@Test
	public void f()  {
		String baseUrl = "https://www.seb.lt/skaiciuokles/lizingo-skaiciuokle";
        System.out.println("Launching Google Chrome browser"); 
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Daiva1\\Desktop\\configuration\\resources\\drivers\\chromedriver_win32\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get(baseUrl);
        //Pasirenkama angl� kalba
        driver.findElement(By.xpath("/html/body/div[4]/div/div[4]/ul/li[1]/a/span")).click();
        //driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        WebElement element6 = driver.findElement(By.xpath("//*[@id=\"menu01\"]/div[1]/div/div/ul/li/a/span")); 
        element6.click();
        System.out.println("paklikino English");
        //�vedama automobilio �sigijimo kaina
        driver.switchTo().frame("calculator-frame-06");
        WebElement element = driver.findElement(By.id("f-summa")); 
        element.click();
        System.out.println("paklikino");
        element.sendKeys("10000");
        System.out.println("ivede");
        //�vedama pal�kan� norma
        WebElement element1 = driver.findElement(By.id("f-likme")); 
        element1.click();
        System.out.println("paklikino1");
        element1.clear();
        element1.sendKeys("4");
        System.out.println("ivede1");
        //�vedamas paskolos i�davimo terminas
        Select drptermins= new Select(driver.findElement(By.name("termins")));
        drptermins.selectByVisibleText("4 years");
        //pasirenkamas mato vienetas (procentais ar EUR)
        Select drpmaksa_type= new Select(driver.findElement(By.name("maksa_type")));
        drpmaksa_type.selectByVisibleText("EUR");
        //�vedama pradin�s �mokos suma
        WebElement element2 = driver.findElement(By.id("f-maksa")); 
        element.click();
        System.out.println("paklikino2");
        element2.sendKeys("20");
        System.out.println("ivede2");
       // �vedamas likutis
        WebElement element3 = driver.findElement(By.id("f-rest")); 
        element3.click();
        System.out.println("paklikino3");
        element3.clear();
        element3.sendKeys("10");
        System.out.println("ivede3");
       // spaud�iamas mygtukas Calculate
        WebElement element4 = driver.findElement(By.xpath("/html/body/div/form/fieldset/div/div[1]/footer/div[2]/button")); 
        element4.click();
        System.out.println("paklikino Calculate");
       //spaud�iamas mygtukas Payment shedule
        WebElement element7 = driver.findElement(By.xpath("/html/body/div/form/fieldset/div/div[2]/footer/div/div/button[2]")); 
        element7.click();
        System.out.println("paklikino Payment shedule");
        //tikrinama, ar ekrane vaizduojamas grafikas, tai yra tekstas Payment shedule
        String pshed = "Payment schedule";
        WebElement element8 = driver.findElement(By.xpath("/html/body/div/div[2]/h2")); 
        Assert.assertEquals(element8.getText(),pshed, "N�ra mok�jimo grafiko");
        //tikrinama apskai�iuota First installment reik�m�(laukas First installment) su grafike rodoma (eilut�s Nr. 1 laukas Total payment 
        String finstallment = "20.00";
        WebElement element10 = driver.findElement(By.xpath("/html/body/div/div[2]/table/tbody/tr[3]/td[6]")); 
        Assert.assertEquals(element10.getText(),finstallment, "First installment sumos nesutampa");
        //spaud�iamas mygtukas Print mok�jimo grafikui atspausdinti
        //!!!!!!!! Spausdinim� reikia patikrinti rankiniu b�du, ne automatiyuotai!!!!!!!!
        WebElement element9 = driver.findElement(By.xpath("/html/body/div/div[2]/button")); 
        element9.click();
        System.out.println("paklikino Print");
                       
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Starting Test On Chrome Browser");
  }

  @AfterMethod
  public void afterMethod() {
	  driver.close();
	  System.out.println("Finished Test On Chrome Browser");
  }

}
